﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace TCC
{
    public partial class Servicos
    {
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        SqlDataAdapter da;
        DataSet ds;
        SqlCommand comm;



        public List<Servicos> ListaServicos()
        {
            da = new SqlDataAdapter("select ServicoID, Descricao from tecnosolution.dbo.Servicos", sqlCon);
            ds = new DataSet();
            da.Fill(ds);

            List<Servicos> lista = new List<Servicos>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                Servicos s = new Servicos();
                s.ServicoID = (int)dr["ServicoID"];
                s.Desc = dr["Descricao"].ToString();

                lista.Add(s);
            }

            return lista;
        }

        public List<Servicos> ListServicos()
        {
            da = new SqlDataAdapter("select ServicoID, Descricao from tecnosolution.dbo.Servicos", sqlCon);
            ds = new DataSet();
            da.Fill(ds);

            List<Servicos> lista = new List<Servicos>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                Servicos s = new Servicos();
                s.ServicoID = (int)dr["ServicoID"];
                s.Desc = dr["Descricao"].ToString();

                lista.Add(s);
            }

            return lista;
        }


        public void Servico(Servicos S)
        {

            comm = new SqlCommand("Serv",sqlCon);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.Add("@Descricao", SqlDbType.VarChar).Value = S.Desc;
            comm.Parameters.Add("@ServicoID", SqlDbType.Int).Value = S.ServicoID;

            sqlCon.Open();
            comm.ExecuteNonQuery();
            sqlCon.Close();

        }

        public int ProximoID()
        {
            da = new SqlDataAdapter("select (MAX(ServicoID)+1)  from tecnosolution.dbo.Servicos", sqlCon);

            DataSet ds = new DataSet();

            da.Fill(ds);


            int RetornaID = int.Parse(ds.Tables[0].Rows[0].ItemArray[0].ToString());

            return RetornaID;
        }
    
    
    
    
    }




}