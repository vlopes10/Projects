﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace TCC
{
    public partial class Usuarios
    {

        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        SqlDataAdapter da;
        DataSet ds;
        SqlCommand comm;

        public bool Login(Usuarios U)//método que vai buscar usuario e senha;
        {

            da = new SqlDataAdapter("select * from tecnosolution.dbo.Usuarios where Email='" + U.Email + "' and Senha='" + U.Senha + "'", sqlCon); //
            ds = new DataSet();
            da.Fill(ds);

            bool logado;

            if (ds.Tables[0].Rows.Count > 0)//se houver algum usuario e senha iguais aos digitados ele retorna bool=verdadeiro;
                logado = true;
            else
                logado = false;

            return logado;
        }


        public List<Usuarios> ListarUsuarios()
        {
            da = new SqlDataAdapter("select * from tecnosolution.dbo.Usuarios", sqlCon);
            ds = new DataSet();
            da.Fill(ds);

            List<Usuarios> listUsu = new List<Usuarios>();

            foreach (DataRow dr in ds.Tables[0].Rows) //foreach no DataSet (Dados retornados pelo data adapter);
            {
                Usuarios u = new Usuarios();
                u.UsuarioID = (int)dr["UsuarioID"];//dr NÃO É DATAREADER!!! NÃO CONFUNDIR;
                u.GrupoUsuarioID = (int)dr["GrupoUsuarioID"];
                u.Nome = dr["Nome"].ToString();
                u.Email = dr["Email"].ToString();
                u.Senha = dr["Senha"].ToString();
                u.Ativo = (int)dr["Ativo"];
                u.Cep = dr["Cep"].ToString();
                u.Numero = (int)dr["Numero"];
                u.PontoReferencia = dr["PontoReferencia"].ToString();
                u.Telefone = dr["Telefone"].ToString();
                u.Celular = dr["Celular"].ToString();
                listUsu.Add(u);
            }

            return listUsu;
        }
        public List<Usuarios> SelectCliente(Usuarios U)
        {
            da = new SqlDataAdapter("select * from tecnosolution.dbo.Usuarios where Email='" + Orcamentos.Email + "'", sqlCon);
            ds = new DataSet();
            da.Fill(ds);

            List<Usuarios> listS = new List<Usuarios>();

            foreach (DataRow dr in ds.Tables[0].Rows) 
            {
                Usuarios u = new Usuarios();
                u.UsuarioID = (int)dr["UsuarioID"];
                u.GrupoUsuarioID = (int)dr["GrupoUsuarioID"];
                u.Nome = dr["Nome"].ToString();
                u.Email = dr["Email"].ToString();
                u.Senha = dr["Senha"].ToString();
                u.Ativo = (int)dr["Ativo"];
                u.Cep = dr["Cep"].ToString();
                u.Numero = (int)dr["Numero"];
                u.PontoReferencia = dr["PontoReferencia"].ToString();
                u.Telefone = dr["Telefone"].ToString();
                u.Celular = dr["Celular"].ToString();
                listS.Add(u);
            }

            return listS;
        }

        public int ItemGrupoUsuarioID(string Email, string Senha)
        {
            da = new SqlDataAdapter("select GrupoUsuarioID from tecnosolution.dbo.Usuarios where Email = '" + Email + "' and Senha='" + Senha + "'", sqlCon);
            ds = new DataSet();
            da.Fill(ds);

            return int.Parse(ds.Tables[0].Rows[0].ItemArray[0].ToString());
        }

    
        public int ProximoID()
        {
            da = new SqlDataAdapter("select (MAX(UsuarioID)+1)  from tecnosolution.dbo.Usuarios", sqlCon);

            DataSet ds = new DataSet();

            da.Fill(ds);


            int RetornaID = int.Parse(ds.Tables[0].Rows[0].ItemArray[0].ToString());

            return RetornaID;
        }


        public string RecSenha(Usuarios U)
        {
            da = new SqlDataAdapter("select Senha from tecnosolution.dbo.Usuarios where Email='" + U.Email + "'", sqlCon);
            ds = new DataSet();
            da.Fill(ds);
            return ds.Tables[0].Rows[0].ItemArray[0].ToString();
        }

        public void Salvar(Usuarios U)
        {

            comm = new SqlCommand("ProcAltCliente", sqlCon);
            comm.CommandType = CommandType.StoredProcedure;
           // SqlCommand comm = new SqlCommand("  update tecnosolution.dbo.Usuarios set Cep='" + U.Cep + "', Numero=" + U.Numero + ",PontoReferencia='" + U.PontoReferencia + "',Telefone='" + U.Telefone + "',Celular='" + U.Celular + "',Nome = '" + U.Nome + "',Email = '" + U.Email + "',Senha ='" + U.Senha + "',Ativo='" + U.Ativo + "' where Email = '" + U.Email + "'", sqlCon);
            comm.Parameters.Add("@UsuarioID", SqlDbType.Int).Value = U.UsuarioID;
            comm.Parameters.Add("@GrupoUsuarioID", SqlDbType.Int).Value = U.GrupoUsuarioID;
            comm.Parameters.Add("@Nome", SqlDbType.VarChar).Value = U.Nome;
            comm.Parameters.Add("@Email", SqlDbType.VarChar).Value = U.Email;
            comm.Parameters.Add("@Senha", SqlDbType.VarChar).Value = U.Senha;
            comm.Parameters.Add("@Ativo", SqlDbType.Int).Value = U.Ativo;
            comm.Parameters.Add("@Cep", SqlDbType.VarChar).Value = U.Cep;
            comm.Parameters.Add("@Telefone", SqlDbType.VarChar).Value = U.Telefone;
            comm.Parameters.Add("@Celular", SqlDbType.VarChar).Value = U.Celular;
            comm.Parameters.Add("@PontoReferencia", SqlDbType.VarChar).Value = U.PontoReferencia;
            comm.Parameters.Add("@Numero", SqlDbType.Int).Value = U.Numero;

            sqlCon.Open();
            comm.ExecuteNonQuery();
            sqlCon.Close();



        }

        
        
    }
}