﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using TCC;
using System.Configuration;

namespace TCC
{
    public partial class Orcamento
    {
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        SqlDataAdapter da;
        SqlCommand comm;
        DataSet ds;
        SqlDataReader dr;

        public int BuscarUser()
        {
            int ID = 0;
            comm = new SqlCommand("SELECT UsuarioID from Usuarios where Email = '" + Orcamentos.Email + "'", sqlCon);
            sqlCon.Open();
            dr = comm.ExecuteReader();
            if (dr.Read())
                ID = int.Parse(dr["UsuarioID"].ToString());
            sqlCon.Close();
            return ID;
        }

        public int BuscarID()
        {
            da = new SqlDataAdapter("SELECT MAX((OrcamentoID)+1) AS OrcamentoID from Orcamento", sqlCon);
            ds = new DataSet();
            da.Fill(ds);
            int ID = int.Parse(ds.Tables[0].Rows[0].ItemArray[0].ToString());
            return ID;
        }

        public void Salvar(Orcamento O)
        {
            //comm = new SqlCommand("INSERT INTO Orcamento (OrcamentoID,UsuarioID,Titulo,Descricao,Valor,Anexo,Data) VALUES (" + BuscarID() + "," + BuscarUser() + ",'" + O.Titulo + "','" + O.Descricao + "','indefinido','" + O.Anexo + "','" + O.Data + "')", sqlCon);
            //comm = new SqlCommand("INSERT INTO Orcamento (OrcamentoID,UsuarioID,Titulo,Descricao,Valor,Anexo,Data) VALUES (" + BuscarID() + ","+BuscarUser()+",'" + O.Titulo + "','" + O.Descricao + "','indefinido','" + O.Anexo + "','" + O.Data + "')", sqlCon);
            SqlCommand comm = new SqlCommand("ProcCadOrc",sqlCon);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add("@OrcamentoID", SqlDbType.Int).Value = BuscarID();
            comm.Parameters.Add("@UsuarioID", SqlDbType.Int).Value = BuscarUser();
            comm.Parameters.Add("@Titulo", SqlDbType.VarChar).Value = O.Titulo;
            comm.Parameters.Add("@Descricao", SqlDbType.VarChar).Value = O.Descricao;
            comm.Parameters.Add("@Valor", SqlDbType.VarChar).Value = "INDEFINIDO";
            comm.Parameters.Add("@Anexo", SqlDbType.VarChar).Value = O.Anexo;
            comm.Parameters.Add("@Data", SqlDbType.DateTime).Value = O.Data;

            sqlCon.Open();
            comm.ExecuteNonQuery();
            sqlCon.Close();
            O.Result = "CADASTRADO COM SUCESSO!";
        }

        public int BuscarID2()
        {
            da = new SqlDataAdapter("SELECT MAX(OrcamentoID) AS OrcamentoID from Orcamento", sqlCon);
            ds = new DataSet();
            da.Fill(ds);
            int ID = int.Parse(ds.Tables[0].Rows[0].ItemArray[0].ToString());
            return ID;
        }

        public void Cadastrar(Orcamento O)
        {
            foreach(string Itens in O.Lista)
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT ServicoID from Servicos where Descricao = '"+Itens+"'",sqlCon);
                DataSet ds = new DataSet();
                da.Fill(ds);
                int ID = int.Parse(ds.Tables[0].Rows[0].ItemArray[0].ToString());
                //comm = new SqlCommand("INSERT INTO OrcamentoServicoAndamento (OrcamentoID,ServicoID,AndamentoID) VALUES (" + BuscarID2() + ","+ ID +",1)", sqlCon);
                SqlCommand comm = new SqlCommand("ProcCadOrcamentoServicoAndamento",sqlCon);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.Add("@OrcamentoID", SqlDbType.Int).Value = BuscarID2();
                comm.Parameters.Add("@ServicoID", SqlDbType.Int).Value = ID;
                comm.Parameters.Add("@AndamentoID", SqlDbType.Int).Value = 1;

                sqlCon.Open();
                comm.ExecuteNonQuery();
                sqlCon.Close();
            }
        }

        public List<string> Status()
        {
            da = new SqlDataAdapter("select Descricao from Servicos", sqlCon);
            ds = new DataSet();
            da.Fill(ds);
            List<string> lista = new List<string>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                lista.Add(dr["Descricao"].ToString());
            }
            return lista;
        }

        public void Alterar()
        {
            comm = new SqlCommand("UPDATE Orcamento SET AndamentoID = 1 WHERE OrcamentoID = 1", sqlCon);
            sqlCon.Open();
            comm.ExecuteNonQuery();
            sqlCon.Close();
        }
    }
}