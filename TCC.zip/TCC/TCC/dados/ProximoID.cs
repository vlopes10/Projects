﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace TCC
{
    public partial class ProximoID
    {
        public static int NextID()
        {
            ProximoID p = new ProximoID();

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);

            SqlDataAdapter da = new SqlDataAdapter("select (MAX(" + p.campo + ")+1)  from " + p.tabela + "", con);

            DataSet ds = new DataSet();

            da.Fill(ds);


            int RetornaID = int.Parse(ds.Tables[0].Rows[0].ItemArray[0].ToString());

            return RetornaID;
        }
    }
}