﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI.WebControls;

namespace TCC
{
    public partial class MenuItens
    {
         SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        SqlDataAdapter da;
        DataSet ds;

        public List<MenuItens> Lista(int GrupoUsuarioID)
        {
            da = new SqlDataAdapter("select * from v_MenuGrupo where GrupoUsuarioID =" + GrupoUsuarioID, sqlCon);
            ds = new DataSet();
            da.Fill(ds);

            List<MenuItens> ListMI = new List<MenuItens>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                MenuItens MI = new MenuItens();
                MI.MenuItensID = (int)dr["MenuItensID"];
                MI.Texto = dr["Texto"].ToString();
                MI.Link = dr["Link"].ToString();
                if (dr["ParentID"].ToString() != "")
                    MI.ParentID = (int)dr["ParentID"];

                MI.Ordem = (int)dr["Ordem"];
                MI.GrupoUsuarioID = (int)dr["GrupoUsuarioID"];

                ListMI.Add(MI);
            }

            return ListMI;
        }

        public void MontaMenuGrupo(MenuItemCollection ciItens, List<MenuItens> listMenuGrupo, int? ParentID)
        {
            foreach (MenuItens mmItem in listMenuGrupo.FindAll(p => p.ParentID == ParentID))
            {
                MenuItem newItem = new MenuItem();
                newItem.Text = mmItem.Texto;
                newItem.NavigateUrl = mmItem.Link;

                ciItens.Add(newItem);

                if (listMenuGrupo.FindAll(p => p.ParentID == mmItem.ParentID).Count > 0)
                    MontaMenuGrupo(newItem.ChildItems, listMenuGrupo, mmItem.MenuItensID);
            }
        }
    }
}