﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace TCC
{
    public partial class andamento
    {


        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);

        SqlDataAdapter da;
        DataSet ds;

        public List<andamento> ListaAndamento()
        {
            da = new SqlDataAdapter("select AndamentoID, Descricao, Img_URL from dbo.Andamento", sqlCon);
            ds = new DataSet();
            da.Fill(ds);

            List<andamento> lista = new List<andamento>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                andamento a = new andamento();
                a.AndamentoID = (int)dr["AndamentoID"];
                a.Descricao = dr["Descricao"].ToString();
                a.ImgUrl = dr["Img_Url"].ToString();

                lista.Add(a);
            }

            return lista;











        }



        



    }
}