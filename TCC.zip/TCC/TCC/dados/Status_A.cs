﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace TCC
{
    public partial class Status_A
    {
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        SqlDataAdapter da;
        DataSet ds;

        public DataSet BuscarDados(Status_A S)
        {
            da = new SqlDataAdapter("SELECT dbo.OrcamentoServicoAndamento.OrcamentoID, dbo.OrcamentoServicoAndamento.ServicoID, dbo.OrcamentoServicoAndamento.AndamentoID, dbo.Usuarios.Nome, dbo.Orcamento.Titulo, dbo.Andamento.Descricao FROM dbo.Andamento INNER JOIN dbo.OrcamentoServicoAndamento ON dbo.Andamento.AndamentoID = dbo.OrcamentoServicoAndamento.AndamentoID INNER JOIN dbo.Orcamento ON dbo.OrcamentoServicoAndamento.OrcamentoID = dbo.Orcamento.OrcamentoID INNER JOIN dbo.Usuarios ON dbo.Orcamento.UsuarioID = dbo.Usuarios.UsuarioID where dbo.Usuarios.Nome like '%" + S.Nome + "%'", sqlCon);
            ds = new DataSet();
            da.Fill(ds);
            return ds;
        }

        public List<string> ListAndamento()
        {
            da = new SqlDataAdapter("SELECT Descricao FROM Andamento", sqlCon);
            ds = new DataSet();
            da.Fill(ds);
            List<string> lista = new List<string>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                lista.Add(dr["Descricao"].ToString());
            }
            return lista;
        }

        public void BuscarAndamentoID(Status_A S)
        {
            da = new SqlDataAdapter("SELECT AndamentoID from Andamento WHERE Descricao = '" + S.Andamento + "'", sqlCon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            S.AndamentoID = int.Parse(ds.Tables[0].Rows[0].ItemArray[0].ToString());
        }

        public void Atualizar(Status_A S)
        {
            SqlCommand comm = new SqlCommand("ProcAtualizarStatus", sqlCon);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add("@AndamentoID", SqlDbType.Int).Value = S.AndamentoID;
            comm.Parameters.Add("@OrcamentoID", SqlDbType.Int).Value = S.OrcamentoID;
            comm.Parameters.Add("@ServicoID", SqlDbType.Int).Value = S.ServicoID;

            sqlCon.Open();
            comm.ExecuteNonQuery();
            sqlCon.Close();
        }

        }
    }
