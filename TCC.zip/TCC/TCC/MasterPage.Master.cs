﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TCC
{
    public partial class MasterPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if ((Session["Email"] == null) && (Session["Senha"] == null))
            {
              
                MenuItens mn = new MenuItens();
                mn.MontaMenuGrupo(Menu1.Items, mn.Lista(0), null);
            }
            else
            {
                if (!Page.IsPostBack)
                {
                    Usuarios u = new Usuarios();
                    ListarMenuGrupo(u.ItemGrupoUsuarioID(Session["Email"].ToString(), Session["Senha"].ToString()));
                }
            }
        }

        protected void btnEntrar_Click(object sender, EventArgs e)
        {
             
            Usuarios U = new Usuarios(); 
            U.Email = txtUsuario.Text;
            U.Senha = txtSenha.Text;
            
           
           if (U.Login(U))
           {
               Session["Email"] = txtUsuario.Text;
               Session["Senha"] = txtSenha.Text;
               Orcamentos.Email = txtUsuario.Text;
               Session.Timeout = 10;
              
               ListarMenuGrupo(U.ItemGrupoUsuarioID(txtUsuario.Text, txtSenha.Text));
              // Response.Redirect("ExcServ.aspx");
           }
          
             


           lblUsuario.Visible = false;
           lblSenha.Visible = false;
           txtSenha.Visible = false;
           txtUsuario.Visible = false;
           HyperLink1.Visible = false;
           btnEntrar.Visible = false;
        }
         public void ListarMenuGrupo(int GrupoUsuarioID)
        {
            MenuItens MI = new MenuItens();

            MI.MontaMenuGrupo(Menu1.Items, MI.Lista(GrupoUsuarioID), null);
            lblUsuario.Visible = false;
            lblSenha.Visible = false;
            txtSenha.Visible = false;
            txtUsuario.Visible = false;
            HyperLink1.Visible = false;
            btnEntrar.Visible = false;
        }

         protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
         {

         }
        
    }
}