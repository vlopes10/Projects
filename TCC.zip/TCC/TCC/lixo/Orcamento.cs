﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using TCC;
using System.Configuration;

namespace TCC
{
    public partial class Orcamentos
    {
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        SqlDataAdapter da;
        SqlCommand comm;
        DataSet ds;
        IDataReader dr;

        public int BuscarUser()
        {
            int ID = 0;
            comm = new SqlCommand("SELECT UsuarioID from Usuarios where Email = '" + Orcamentos.Email + "'", sqlCon);
            sqlCon.Open();
            dr = comm.ExecuteReader();
            if (dr.Read())
                ID = int.Parse(dr["UsuarioID"].ToString());
            sqlCon.Close();
            return ID;
        }

        public int BuscarID()
        {
            da = new SqlDataAdapter("SELECT MAX((OrcamentoID)+1) AS OrcamentoID from Orcamento", sqlCon);
            ds = new DataSet();
            da.Fill(ds);
            int ID = int.Parse(ds.Tables[0].Rows[0].ItemArray[0].ToString());
            return ID;
        }

        public void Salvar(Orcamentos O)
        {
            comm = new SqlCommand("INSERT INTO Orcamento (OrcamentoID,UsuarioID,AndamentoID,ServicoID,Titulo,Descricao,Valor,Anexo,Data) VALUES (" + BuscarID() + "," + BuscarUser() + ",0," + O.ServicoID + ",'" + O.Titulo + "','" + O.Descricao + "','indefinido','" + O.Anexo + "','" + O.Data + "')", sqlCon);
            sqlCon.Open();
            comm.ExecuteNonQuery();
            sqlCon.Close();
            O.Result = "CADASTRADO COM SUCESSO!";
        }

        public List<string> Status()
        {
            da = new SqlDataAdapter("select Descricao from Servicos", sqlCon);
            ds = new DataSet();
            da.Fill(ds);
            List<string> lista = new List<string>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                lista.Add(dr["Descricao"].ToString());
            }
            return lista;
        }

        public void Alterar()
        {
            comm = new SqlCommand("UPDATE Orcamento SET AndamentoID = 1 WHERE OrcamentoID = 1", sqlCon);
            sqlCon.Open();
            comm.ExecuteNonQuery();
            sqlCon.Close();
        }

        public void Deletar(string OrcamentoID)
        {
            comm = new SqlCommand("delete from Orcamento where OrcamentoID = '"+ OrcamentoID+"'", sqlCon);

            sqlCon.Open();
            comm.ExecuteNonQuery();
            sqlCon.Close();
        }

        public void ExcluirOrcamento (string OrcamentoID)
        {
            comm = new SqlCommand("delete from OrcamentoServicoAndamento where OrcamentoID = '" + OrcamentoID + "'", sqlCon);
            sqlCon.Open();
            comm.ExecuteNonQuery();
            sqlCon.Close();

        }

        public List<Orcamentos> ListarOrcamentos()
        {
            da = new SqlDataAdapter("select * from Orcamento ", sqlCon);
            ds = new DataSet();
            da.Fill(ds);

            List<Orcamentos> ListOrcamentos = new List<Orcamentos>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                Orcamentos O = new Orcamentos();

                O.OrcamentoID = (int)dr["OrcamentoID"];
                O.UsuarioID = (int)dr["UsuarioID"];
                O.Descricao = dr["Descricao"].ToString();
                O.Titulo = dr["Titulo"].ToString();
                O.Valor = dr["Valor"].ToString();
                O.Data = dr["Data"].ToString();
               
                ListOrcamentos.Add(O);
            }

            return ListOrcamentos;
        }


    }
}