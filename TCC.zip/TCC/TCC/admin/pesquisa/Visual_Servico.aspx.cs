﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TCC.admin.pesquisa
{
    public partial class Visual_Servico : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnPesquisar_Click(object sender, EventArgs e)
        {
            Servicos S = new Servicos();
            GridView1.DataSource = S.ListServicos();
            GridView1.DataBind();
        }
    }
}