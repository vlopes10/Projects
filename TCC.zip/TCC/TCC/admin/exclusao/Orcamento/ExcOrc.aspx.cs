﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TCC.admin.exclusao.Orcamento
{
    public partial class ExcOrc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        DataSet ds = new DataSet();
        public void ListarOrcamentos()
        {
            Orcamentos O = new Orcamentos();

            gvOrcamentos.DataSource = O.ListarOrcamentos();
            gvOrcamentos.DataBind();

        }


        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orcamento where UsuarioID = ' " + txtCliente.Text + "'", sqlCon);
            ds = new DataSet();
            da.Fill(ds);
            gvOrcamentos.DataSource = ds;
            gvOrcamentos.DataBind();
            txtCliente.Text = string.Empty;
        }


        protected void gvOrcamentos_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Orcamentos o = new Orcamentos();

            o.ExcluirOrcamento(gvOrcamentos.Rows[e.RowIndex].Cells[0].Text);
            o.Deletar(gvOrcamentos.Rows[e.RowIndex].Cells[0].Text);
            ListarOrcamentos();
        }

    }
}