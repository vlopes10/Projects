﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

using System.Data;

namespace TCC.admin.cadastro.Usuario
{
    public partial class Alteracao_Cliente : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if ((Session["Usuario"] == null) && (Session["Senha"] == null))
            //{
            //    Response.Redirect(@"~/Default.aspx");
            //}
            //else
            //    ListarUsuarios();

        }
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        public static string email;
        public static string result;
        SqlDataAdapter da;
        DataSet ds;

        public void ListarUsuarios()
        {
            Usuarios u = new Usuarios();
            GridView1.DataSource = u.ListarUsuarios();
            GridView1.DataBind();

        }

        public int ProximoID()
        {

            SqlDataAdapter da = new SqlDataAdapter("select (MAX(DadosID)+1)  from tecnosolution.dbo.DadosClientes", con);

            DataSet ds = new DataSet();

            da.Fill(ds);


            int RetornaID = int.Parse(ds.Tables[0].Rows[0].ItemArray[0].ToString());

            return RetornaID;


        }

        protected void btnAlterarCli_Click(object sender, EventArgs e)
        {
            Usuarios u = new Usuarios();
            u.Nome = txtNome.Text;
            u.Email = txtEmail.Text;
            u.Ativo = int.Parse(txtAtivo.Text);
            u.Cep = txtCep.Text;
            u.Numero = int.Parse(txtNu.Text);
            u.PontoReferencia = txtPr.Text;
            u.Celular = txtCel.Text;
            u.Telefone = txtResi.Text;
            u.Senha = txtSenha.Text;
            u.GrupoUsuarioID = 2;
            u.UsuarioID = int.Parse(id.Value.ToString());

            u.Salvar(u);
            ListarUsuarios();
            Limpar();

        }

        public void BuscarClientes()
        {
            da = new SqlDataAdapter("select  UsuarioID,GrupoUsuarioID,Ativo,Nome,Email,Cep,Numero,PontoReferencia,Celular,Telefone,Senha from tecnosolution.dbo.Usuarios where Email like '%" + TextBox1.Text + "%' ", con);
            ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            BuscarClientes();
            TextBox1.Text = string.Empty;
        }


        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            id.Value = GridView1.Rows[e.RowIndex].Cells[0].Text;
            id1.Value = GridView1.Rows[e.RowIndex].Cells[1].Text;
            txtAtivo.Text = GridView1.Rows[e.RowIndex].Cells[2].Text;
            txtNome.Text = GridView1.Rows[e.RowIndex].Cells[3].Text;
            txtEmail.Text = GridView1.Rows[e.RowIndex].Cells[4].Text;
            txtCep.Text = GridView1.Rows[e.RowIndex].Cells[5].Text;
            txtNu.Text = GridView1.Rows[e.RowIndex].Cells[6].Text;
            txtPr.Text = GridView1.Rows[e.RowIndex].Cells[7].Text;
            txtCel.Text = GridView1.Rows[e.RowIndex].Cells[8].Text;
            txtResi.Text = GridView1.Rows[e.RowIndex].Cells[9].Text;
            txtSenha.Text = GridView1.Rows[e.RowIndex].Cells[10].Text;
            BuscarClientes();
        }

        public void Limpar()
        {
            id.Value = "";
            id1.Value = "";
            txtNome.Text = "";
            txtCep.Text = "";
            txtNu.Text = "";
            txtAtivo.Text = "";
            txtPr.Text = "";
            txtCel.Text = "";
            txtResi.Text = "";
            txtEmail.Text = "";

        }
    }
}