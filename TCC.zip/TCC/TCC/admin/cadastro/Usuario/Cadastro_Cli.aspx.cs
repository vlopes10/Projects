﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace TCC.admin.cadastro.Usuario
{
    public partial class Cadastro_Cli : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if ((Session["Usuario"] == null) && (Session["Senha"] == null))
            {
                Response.Redirect(@"~/Default.aspx");
            }
           
               
        }
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        SqlDataAdapter da;
        DataSet ds;
        SqlCommand comm;

        public static string email;
        public static string result;

        public void Cadastro()
        {
            Usuarios U = new Usuarios();

            U.UsuarioID = U.ProximoID();
            U.GrupoUsuarioID = 2;
            U.Email = txtEmail.Text;
            U.Senha = txtSenha.Text;
            U.Nome = txtNome.Text;
            U.Ativo = 1;
            U.Cep="NULL";
            U.Telefone = "NULL";
            U.Celular = "NULL";
            U.PontoReferencia = "NULL";
            U.Numero = 0;
       
            
            U.Salvar(U);
        }

     

        protected void btnCad_Cli_Click1(object sender, EventArgs e)
        {
            Cadastro();
        }
    }
}