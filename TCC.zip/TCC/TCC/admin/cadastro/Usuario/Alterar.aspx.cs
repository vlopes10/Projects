﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TCC.admin.cadastro.Usuario
{
    public partial class Alterar : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if ((Session["Usuario"] == null) && (Session["Senha"] == null))
            {
                Response.Redirect(@"~/Default.aspx");
            }


            da = new SqlDataAdapter("select * from tecnosolution.dbo.Usuarios where Email='" + Orcamentos.Email + "'", sqlCon);
            ds = new DataSet();
            da.Fill(ds);

            List<Usuarios> listS = new List<Usuarios>();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {


                txtNome.Text = dr["Nome"].ToString();
                txtEmail.Text = dr["Email"].ToString();
                txtSenha.Text = dr["Senha"].ToString();
                txtAtivo.Text = dr["Ativo"].ToString();
                txtCep.Text = dr["Cep"].ToString();
                txtNu.Text = dr["Numero"].ToString();
                txtPr.Text = dr["PontoReferencia"].ToString();
                txtResi.Text = dr["Telefone"].ToString();
                txtCel.Text = dr["Celular"].ToString();

            }
               
               
    

        }

        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        SqlDataAdapter da;
        DataSet ds;
        SqlCommand comm;
      
        protected void btnAlterarCli_Click(object sender, EventArgs e)
        {
          
        }
        public void Select(Usuarios U)
        {

            U.SelectCliente(U);
               
                txtAtivo.Text=U.Ativo.ToString();
                txtNome.Text= U.Nome ;
                txtEmail.Text=U.Email ;
                txtCep.Text=U.Cep; 
                txtNu.Text=U.Numero.ToString(); 
                txtPr.Text=U.PontoReferencia; 
                txtCel.Text=U.Celular; 
                txtResi.Text=U.Telefone;
                txtSenha.Text=U.Senha; 
        
        
        }
    }
}