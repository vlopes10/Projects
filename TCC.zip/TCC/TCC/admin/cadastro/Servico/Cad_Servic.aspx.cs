﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TCC.admin.cadastro.Servico
{
    public partial class Cad_Servico : System.Web.UI.Page
    {

        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);
        SqlDataAdapter da;
        DataSet ds;
        SqlCommand comm;



        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void Servicos()
        {
            Servicos S = new Servicos();
            S.Desc = txtDescricao.Text;
            S.ServicoID = S.ProximoID();
            //comm.Parameters.Add("@Descricao", SqlDbType.VarChar).Value = Se.Descricao;

            S.Servico(S);
        }
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            Servicos();
        }
    }
}