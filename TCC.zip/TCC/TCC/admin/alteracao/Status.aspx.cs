﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TCC.admin.alteracao
{
    public partial class Status : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if ((Session["Email"] == null) && (Session["Senha"] == null))
            {
                Response.Redirect(@"~/Default.aspx");
            }
            if (!IsPostBack)
            {
                Status_A S = new Status_A();
                foreach (string i in S.ListAndamento())
                {
                    rdbStatus.Items.Add(i);
                }

            }
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            Status_A S = new Status_A();
            S.Nome = txtNome.Text;
            dgvStatus.DataSource = S.BuscarDados(S);
            dgvStatus.DataBind();
        }

        protected void dgvStatus_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            lblTitulo.Text = dgvStatus.Rows[e.RowIndex].Cells[4].Text;
            HiddenField1.Value = dgvStatus.Rows[e.RowIndex].Cells[0].Text;
            HiddenField2.Value = dgvStatus.Rows[e.RowIndex].Cells[1].Text;
        }

        protected void btnAtualizar_Click(object sender, EventArgs e)
        {
            Status_A S = new Status_A();
            S.OrcamentoID = int.Parse(HiddenField1.Value);
            S.ServicoID = int.Parse(HiddenField2.Value);
            S.Andamento = rdbStatus.SelectedValue;
            S.BuscarAndamentoID(S);
            S.Atualizar(S);
            S.Nome = txtNome.Text;
            dgvStatus.DataSource = S.BuscarDados(S);
            dgvStatus.DataBind();
        }


    }
}