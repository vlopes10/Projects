﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TCC.user.cadastro
{
    public partial class Cad_Orc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
            //    Orcamento O = new Orcamento();
            //    //dgvServicos.DataSource = O.Status();
            //    //dgvServicos.DataBind();
            //    foreach (string Itens in O.Status())
            //    {
            //        cblServicos.Items.Add(Itens);
            //    }
            //}
        }

        protected void BtnEnviar_Click(object sender, EventArgs e)
        {
            //string fileName = Server.HtmlEncode(fileuplAnexos.FileName);
            //string anexo = Path.GetDirectoryName(fileuplAnexos.PostedFile.FileName);
            //fileuplAnexos.PostedFile.SaveAs(anexo);
            Orcamento O = new Orcamento();
            O.Titulo = txtTitulo.Text;
            O.Descricao = txtTexto.Text;
            O.Anexo = fileuplAnexos.FileName.ToString();
            O.Data = DateTime.Parse(Calendario.SelectedDate.ToString());
            O.Lista = new List<string>();
            foreach (ListItem lista in cblServicos.Items)
            {
                if (lista.Selected)
                    O.Lista.Add(lista.Value);
            }

            O.Salvar(O);
            O.Cadastrar(O);
            //lblResult.Text = O.Result;
        }


    }
}