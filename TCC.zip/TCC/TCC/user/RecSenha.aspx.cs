﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

namespace TCC.user
{
    public partial class RecSenha : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public static string result;
        SmtpClient smtp = new SmtpClient();
        MailMessage mail = new MailMessage();
        
        private void EnviarEmail()
        {
            Usuarios U = new Usuarios();
            U.Email = txtEmail.Text;

            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.EnableSsl = true;

            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new System.Net.NetworkCredential("tecnosolution.br@gmail.com", "guiguilherme123");

            mail.From = new MailAddress("tecnosolution.br@gmail.com", "Tecnosolution");

            if (!string.IsNullOrWhiteSpace(txtEmail.Text))
                mail.To.Add(new MailAddress(txtEmail.Text));
            else
                lblresult.Text = ("O campo 'Email' é obrigatório!");


             Usuarios S = new Usuarios();
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.Normal;
            mail.Body = ("Sua nova senha é: '" + U.RecSenha(U));

            smtp.Send(mail);
            lblresult.Text = ("E-mail enviado com sucesso!");
        }

        protected void btnRecSenha_Click(object sender, EventArgs e)
        {
            EnviarEmail();
        }

      

    }
}