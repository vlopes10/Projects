﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TCC.user.pesquisa
{
    public partial class Andamento : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
              ListarServicos();
            

         
        }

        public void ListarServicos()
        {
            Servicos s = new Servicos();

            Dpservico.DataTextField = "Desc";
            Dpservico.DataValueField = "ServicoID";
            Dpservico.DataSource = s.ListaServicos();
            Dpservico.DataBind();

        }

        //protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);

        //    DataSet ds;
        //    Andamento O = new Andamento();
        //    //    SqlDataAdapter DJ = new SqlDataAdapter("select ServicoID from Servicos", con);


        //    SqlDataAdapter da = new SqlDataAdapter("SELECT tecnosolution.dbo.Orcamento.Titulo, tecnosolution.dbo.Servicos.Descricao,tecnosolution. dbo.Andamento.Descricao AS andamento, tecnosolution.dbo.Orcamento.UsuarioID FROM  tecnosolution.dbo.Andamento INNER JOIN  tecnosolution.dbo.OrcamentoServicoAndamento ON  tecnosolution.dbo.Andamento.AndamentoID = tecnosolution. dbo.OrcamentoServicoAndamento.AndamentoID INNER JOIN  tecnosolution.dbo.Orcamento ON tecnosolution. dbo.OrcamentoServicoAndamento.OrcamentoID = tecnosolution. dbo.Orcamento.OrcamentoID INNER JOIN  tecnosolution.dbo.Servicos ON  tecnosolution.dbo.OrcamentoServicoAndamento.ServicoID =  tecnosolution.dbo.Servicos.ServicoID where Email =" + Session["Email"].ToString() + "", sqlCon);

        //    ds = new DataSet();
        //    da.Fill(ds);
        //    GridView1.DataSource = ds;
        //    GridView1.DataBind();

        //}


        public void ListaImagem()
        {
            andamento a = new andamento();
            a.ListaAndamento();





            foreach (andamento j in a.ListaAndamento())
            {
                if (a.AndamentoID == 1)
                {

                    Image1.ImageUrl = a.ImgUrl;
                }

                if (a.AndamentoID == 2)
                {
                    Image1.ImageUrl = a.ImgUrl;
                    Image2.ImageUrl = a.ImgUrl;

                }

                if (a.AndamentoID == 3)
                {

                    Image1.ImageUrl = a.ImgUrl;
                    Image2.ImageUrl = a.ImgUrl;
                    Image3.ImageUrl = a.ImgUrl;

                }

                if (a.AndamentoID == 4)
                {

                    Image1.ImageUrl = a.ImgUrl;
                    Image2.ImageUrl = a.ImgUrl;
                    Image3.ImageUrl = a.ImgUrl;
                    Image4.ImageUrl = a.ImgUrl;

                }





            }

        }

    

   


        protected void Dpservico_SelectedIndexChanged1(object sender, EventArgs e)
        {
          

                SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["Conexao"].ConnectionString);

                DataSet ds;
                Andamento O = new Andamento();
                //    SqlDataAdapter DJ = new SqlDataAdapter("select ServicoID from Servicos", con);


                // SqlDataAdapter da = new SqlDataAdapter("SELECT tecnosolution.dbo.Orcamento.Titulo, tecnosolution.dbo.Servicos.Descricao,tecnosolution. dbo.Andamento.Descricao AS andamento, tecnosolution.dbo.Orcamento.UsuarioID FROM  tecnosolution.dbo.Andamento INNER JOIN  tecnosolution.dbo.OrcamentoServicoAndamento ON  tecnosolution.dbo.Andamento.AndamentoID = tecnosolution. dbo.OrcamentoServicoAndamento.AndamentoID INNER JOIN  tecnosolution.dbo.Orcamento ON tecnosolution. dbo.OrcamentoServicoAndamento.OrcamentoID = tecnosolution. dbo.Orcamento.OrcamentoID INNER JOIN  tecnosolution.dbo.Servicos ON  tecnosolution.dbo.OrcamentoServicoAndamento.ServicoID =  tecnosolution.dbo.Servicos.ServicoID where Email =" + Orcamentos.Email + "", sqlCon);
                SqlDataAdapter da = new SqlDataAdapter(" use tecnosolution SELECT  dbo.OrcamentoServicoAndamento.AndamentoID, dbo.Orcamento.Descricao, dbo.Andamento.Descricao AS Expr1, dbo.Usuarios.Email FROM  dbo.OrcamentoServicoAndamento INNER JOIN dbo.Andamento ON dbo.OrcamentoServicoAndamento.AndamentoID = dbo.Andamento.AndamentoID INNER JOIN dbo.Orcamento ON dbo.OrcamentoServicoAndamento.OrcamentoID = dbo.Orcamento.OrcamentoID INNER JOIN dbo.Usuarios ON dbo.Orcamento.UsuarioID = dbo.Usuarios.UsuarioID where Email='" + Orcamentos.Email + "'", sqlCon);
                ds = new DataSet();
                da.Fill(ds);
                GridView1.DataSource = ds;
                GridView1.DataBind();
            
           
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            //andamento a = new andamento();
            //a.AndamentoID = GridView1.Rows[e.RowIndex].Cells[3].Text;

            //ListaImagem();
        }

        //protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    andamento a = new andamento();
        //   // a.AndamentoID = GridView1.Rows[e.RowIndex].Cells[3].Text;

        //    ListaImagem();
        //}

    

      

      


    }
}