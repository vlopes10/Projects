﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TCC
{
    public partial class Usuarios  
    {
        public int UsuarioID { get; set; }
        public int GrupoUsuarioID { get; set; }
        public int Ativo { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Cep { get; set; }
        public int Numero { get; set; }
        public string PontoReferencia { get; set; }
        public string Celular { get; set; }
        public string Telefone { get; set; }
        public string Senha { get; set; }
   

        public Usuarios() { }
    }
}