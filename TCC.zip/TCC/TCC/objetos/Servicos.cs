﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TCC
{
    public partial class Servicos
    {
        public string Desc { get; set; }
        public int ServicoID { get; set; }

        

     


        public Servicos() { }



    }
}