﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TCC
{
    public partial  class andamento
    {

        public int AndamentoID { get; set; }
        public string Descricao { get; set; }
        public string ImgUrl { get; set; }
          
        public andamento() { }
    }
}