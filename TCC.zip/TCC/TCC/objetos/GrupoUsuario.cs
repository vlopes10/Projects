﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace TCC
{
    public  partial class GrupoUsuario
    {
        public int GrupoUsuarioID { get; set; }
        public string Descricao { get; set; }
    }
}