﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TCC
{
    public partial class Orcamento
    {
        public int OrcamentoID { get; set; }
        public string AndamentoID { get; set; }
        public int UsuarioID { get; set; }
        public int ServicoID { get; set; }
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public string Valor { get; set; }
        public string Anexo { get; set; }
        public DateTime Data { get; set; }
        public string Result { get; set; }
        public static string Email { get; set; }
        public List<string> Lista { get; set; }

        public Orcamento()
        { }
    }
}