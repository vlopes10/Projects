﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TCC
{
    public partial class Status_A
    {
        public int OrcamentoID { get; set; }
        public int AndamentoID { get; set; }
        public int ServicoID { get; set; }
        public string Andamento { get; set; }
        public string Nome { get; set; }
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public List<string> Lista { get; set; }

        public Status_A()
        { }
    }
}