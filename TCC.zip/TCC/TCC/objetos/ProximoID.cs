﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TCC
{
    public partial class ProximoID
    {
        public string tabela { get; set;}
        public string campo { get; set; }


      
        public ProximoID()
        { }
    }
}