﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TCC
{
    public partial class MenuItens : GrupoUsuario
    {
        public int MenuItensID { get; set; }
        public string Texto { get; set; }
        public string Link { get; set; }
        public int? ParentID { get; set; }
        public int Ordem { get; set; }

        public MenuItens()
        { }
    }
}